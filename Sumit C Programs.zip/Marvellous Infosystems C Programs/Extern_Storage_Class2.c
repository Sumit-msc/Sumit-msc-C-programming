// This is defination of variable i

int i = 10;

void fun()
{
	printf("\nInside function fun which is extern");
}