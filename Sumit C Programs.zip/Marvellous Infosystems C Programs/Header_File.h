
// Header file contains function declarations, data types , macro etc

// Declaration of functions
void fun();
void gun();

// Variables
int i = 10;

struct demo
{
	int i;
};

// Macro
#define MAX 10

// We can also another header file
#include<stdio.h>